﻿using UnityEngine;
using System.Collections;

public class finish : MonoBehaviour {
    private void Start()
    {
        GameObject canvas = GameObject.Find("Canvas");
        canvas.transform.Find("Text").gameObject.SetActive(false);
    }
    private void OnTriggerEnter(Collider other)
    {
        GameObject canvas = GameObject.Find("Canvas");
        canvas.transform.Find("Text").gameObject.SetActive(true);
    }
}
