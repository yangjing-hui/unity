﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class player : MonoBehaviour {
    public float speed = 20;
    public float turnspeed = 3;
    private Rigidbody rd;
    // Use this for initialization
    private int score = 0;
    public Text text;
	// Use this for initialization
    void OnCollisionEnter(Collision collision)
    {
        //获取碰撞到的游戏物体身上的collider组件
        if (collision.collider.tag == "pickup")
        {
            Destroy(collision.collider.gameObject);
        }
    }

    void OnTriggerEnter(Collider collider)
    {
        if (collider.tag == "pickup")
        {
            score++;
            text.text = score.ToString();
            Destroy(collider.gameObject);
        }
    }	
	// Update is called once per frame
	void Update () {
        if(Input.GetKeyDown(KeyCode.R))
        {
            SceneManager.LoadScene(0);
            Time.timeScale = 1;
            return;
        }
        float x = Input.GetAxis("Horizontal");
        transform.Translate(x * turnspeed * Time.deltaTime, 0, speed * Time.deltaTime);
        if (transform.position.y < -20)
        {
            Time.timeScale = 0;
        }
    }
}
