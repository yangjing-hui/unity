﻿using UnityEngine;
using System.Collections;

public class barriar : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}
    private void OnTriggerEnter(Collider other)
    {
        if (other.name == "player")
        {
           Time.timeScale = 0;
        }
    }
}
