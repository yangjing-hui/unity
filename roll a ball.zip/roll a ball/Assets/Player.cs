﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
public class Player : MonoBehaviour
{
    private Rigidbody rd;
    // Use this for initialization
    private int score = 0;
    public Text text;
    void Start()
    {
        rd = GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void Update()
    {
        float h = Input.GetAxis("Horizontal");
        float v = Input.GetAxis("Vertical");
        rd.AddForce(new Vector3(h, 0, v)*5);
    }

    void OnCollisionEnter(Collision collision)
    {
        //获取碰撞到的游戏物体身上的collider组件
        if(collision.collider.tag == "pickup"){
            Destroy(collision.collider.gameObject);
        }
    }

    void OnTriggerEnter(Collider collider)
    {
        if (collider.tag == "pickup")
        {
            score++;
            text.text = score.ToString();
            Destroy(collider.gameObject);
        }
    }
}